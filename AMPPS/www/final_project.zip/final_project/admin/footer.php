</main>
<footer class="admin-footer">
    <p>&copy; <?= date('Y'); ?> Papi's Pictures Admin</p>
</footer>
</body>
</html>
